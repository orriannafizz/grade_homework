#include "example.h"

void test()
{
  printf("correct answer");
}
