#include "example.h"

void test()
{
  printf("wrong answer");
}
