#include <stdio.h>

void test();